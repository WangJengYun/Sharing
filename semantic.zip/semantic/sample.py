import pandas as pd 
from sentence_transformers import SentenceTransformer
from embedding_clustering import EmbeddingClustering

words = ['交易','交易市場','天氣','下雨','金融','風險','詐貸','你好','銀行','銀行','信用卡','風險']
data = pd.DataFrame({'id':range(len(words)), 'event':words})

model = SentenceTransformer('/Users/mac/Desktop/distiluse-base-multilingual-cased-v1')
embeddings = model.encode(data['event'].tolist(), show_progress_bar = True)
data['embeddings'] = embeddings.tolist()

EC = EmbeddingClustering(method_name = 'BirchModel')
EC.set_data(data, index_col='id', embedding_col= 'embeddings')
EC.fit(threshold = 0.6)
result = EC.transform(
    data,
    index_col = 'id',
    embedding_col = 'embeddings',
    cluster_col = 'cluster',
    cluster_name = 'word',
    center_info = True
)