from ._base import BaseEC
import pandas as pd
from sklearn.cluster import Birch

class BirchModel(BaseEC):

    def __init__(self):

        super().__init__()
        self.empty_ec_model = Birch

    def fit(
        self,
        threshold = 0.5,
        branching_factor = 99,
        n_clusters = None
    ):
        self.ec_model = self.empty_ec_model(
            threshold = threshold,
            branching_factor = branching_factor,
            n_clusters = n_clusters
        )
        self.ec_model.partial_fit(self.embeddings)

    def predict(self, input_embeddings = None):
        if input_embeddings is None:
            return self.ec_model.predict(self.embeddings)

        if input_embeddings is not None:
            return self.ec_model.predict(input_embeddings)

        return None

if __name__ == '__main__':
    from sentence_transformers import SentenceTransformer
    words = ['交易','交易市場','天氣','下雨','金融','風險','詐貸','你好','銀行','銀行','信用卡','風險']
    data = pd.DataFrame({'id':range(len(words)), 'event':words})

    model = SentenceTransformer('/Users/mac/Desktop/distiluse-base-multilingual-cased-v1')
    embeddings = model.encode(data['event'].tolist(), show_progress_bar = True)
    data['embeddings'] = embeddings.tolist()


    EC = BirchModel()
    EC.set_data(data, index_col='id', embedding_col= 'embeddings')
    EC.fit(threshold = 0.6)
    result = EC.transform(
        data,
        index_col = 'id',
        embedding_col = 'embeddings',
        cluster_col = 'CLUSTER',
        cluster_name = 'word'
    )
