import abc
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

class BaseEC:
    def __init__(self):

        self.data = None
        self.index_col = None
        self.embedding_col = None
        self.index_values = None
        self.embeddings = None
        self.len_of_embeddings = None

        self.ec_model = None

    def set_data(
        self,
        data:pd.DataFrame,
        index_col:str,
        embedding_col:str
    ):
        self._check_data(data, index_col, embedding_col)

        self.data = data
        self.index_col = index_col
        self.embedding_col = embedding_col

        assert self.data.shape[0] == self.data[self.index_col].nunique(),\
            f'Please check value of {self.index_col}, the lenght must be equal to the size of data'
        self.index_values = self.data[self.index_col]
        self.embeddings = np.stack(self.data[self.embedding_col])
        self.len_of_embeddings = self.embeddings.shape[0]

    def _check_data(self, data, index_col, embedding_col, cluster_col = None):

        if not isinstance(data, pd.DataFrame):
            raise ValueError('the type of data must be pd.DataFrame,'+\
                             'please check your input.')

        assert index_col in data.columns,\
            f'Not find the {index_col} in the columns of data,'+\
             'please check your input.'

        assert embedding_col in data.columns,\
            f'Not find the {embedding_col} in the columns of data,'+\
             'please check your input.'

        if cluster_col is not None:
            assert cluster_col not in data.columns,\
                f'{cluster_col} is used in subsequent processes,'+\
                 'please replace it with news column name'

    @abc.abstractmethod
    def fit(self):
        return NotImplementedError()

    @abc.abstractmethod
    def predict(self, input_embeddings = None):
        return NotImplementedError()

    def transform(
        self,
        data:pd.DataFrame,
        index_col:str,
        embedding_col:str,
        cluster_col:str = None,
        cluster_name:str = None,
        center_info:bool = False
    ):
        if cluster_col is None:
            cluster_col = 'cluster'

        if cluster_name is None:
            cluster_name = 'cluser'
        input_data = data.copy()

        self._check_data(input_data, index_col, embedding_col, cluster_col)

        embeddings = np.stack(input_data[embedding_col])
        labels = self.predict(embeddings)

        input_data[cluster_col] = [cluster_name + '_' + str(i) for i in labels]

        if center_info:
            cnt_col = 'cnt_of_' + cluster_col
            center_embeddings_col = 'center_of_' + embedding_col

            for col in [cnt_col, center_embeddings_col,'similarity_rank','similarity_scores']:
                assert col not in input_data.columns,\
                    f'{col} is used in subsequent processes,'+\
                    'please replace it with news column name'

            cluster_info = input_data.groupby(cluster_col, as_index = False).\
                agg(
                    {
                        index_col:'count',
                        embedding_col:lambda x:np.stack(x).mean(axis = 0)
                    }
                ).\
                rename(columns = {
                    index_col:cnt_col,
                    embedding_col:center_embeddings_col
                })

            input_data = input_data.merge(cluster_info, how = 'left', on = cluster_col)
            input_data['similarity_scores'] = input_data.\
                        apply(lambda df: cosine_similarity([df[embedding_col]],\
                                        [df[center_embeddings_col]])[0][0], axis = 1)
            input_data['similarity_rank'] = input_data.groupby(cluster_col)['similarity_scores'].\
                        rank('first', ascending = False)

        return input_data

if __name__ == '__main__':
    pass
